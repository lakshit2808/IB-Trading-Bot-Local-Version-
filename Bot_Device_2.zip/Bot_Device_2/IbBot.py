from time import sleep
import pyautogui
import os
import requests
import psutil
from win10toast import ToastNotifier

from ib_insync import *

## IB API ##
ibAPI = '127.0.0.1'
ibPort = 7497
############

def ConnectionCheck():
    ib = IB()
    return ib.connect(ibAPI, ibPort, clientId=1)

scriptPath = './app.exe'
Ib_Trader_Token = '5478898420:AAFOevsAx7vdeVRybBTPDHN8wsAbnKsxeWI'

def BotStatus():
    url = 'https://tradingviewsignal.herokuapp.com/v1/bot1' + '/botstatus'
    res = requests.get(url).json()[0]['botstatus']
    return res  

def AlreadyRunning():
    return "app.exe" in (p.name() for p in psutil.process_iter())


try:
    getConnection = str(ConnectionCheck())
    print('Connected to IB, the bot is ready to go!')
except:
    print('\nNot Connected to IB, Kindly Try logging in again, and then Re-Run the script')   
    sleep(5)  

if 'connected to' in getConnection:
    toast = ToastNotifier()
    toast.show_toast("IB Trading Bot", "IB Trading Bot is running", duration=5)
    os.chdir(r'D:/Desktop/Bots/C - Bot/IB Bot/Bot_Device') ## Change
    print('Script Started')
    while True:
        if AlreadyRunning() is False:
            os.system("start powershell.exe")
            sleep(2)
            pyautogui.write(scriptPath)
            pyautogui.press('enter')
            sleep(1)
            pyautogui.write('exit()')
            pyautogui.press('enter')            