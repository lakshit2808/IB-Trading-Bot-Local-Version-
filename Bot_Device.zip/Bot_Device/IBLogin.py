import os

os.chdir(r"D:\Desktop\Bots\C - Bot\IB Bot\Bot_Device\clientportalapi") ## Change
os.system(r"bin\run.bat root\conf.yaml")